// @ts-check
/** @typedef {import('../../types').Command} Command */

const { ApplicationCommandOptionType, PermissionFlagsBits } = require('discord.js');

/** @type {Command} */
module.exports = {
    name: 'checksong',
    description: 'checks a song',
    //devOnly: Boolean,
    //testOnly: Boolean,
    options: [
        {
            name: 'songURL',
            description: 'song',
            required: true,
            type: ApplicationCommandOptionType.String,
        },
    ],
    
    /**
   * @param {import('discord.js').Client} client
   * @param {import('discord.js').ChatInputCommandInteraction} interaction
   */
    callback: (client, interaction) => {
        interaction.reply(`hey`);
    }
}